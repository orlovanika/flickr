<?php

      /*
       * API Call Request URL
       */

       $url =  "https://api.flickr.com/services/rest/?";

       /*
        * Method We are using for this tutorial  flickr.people.findByEmail
        */

       $url.= "&method=flickr.people.findByEmail";

       /*
        * Put Your API Key Here
        */

       $url.= "&api_key=[Your API Key Here]";

       /*
        * Argument find_email accepts a valid email address
        */
       $url.= "&find_email=[email id of the user to find]";


      $response = file_get_contents($url);

      echo $response;



?>