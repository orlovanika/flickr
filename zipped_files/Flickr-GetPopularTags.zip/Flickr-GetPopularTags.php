<?php


 			/*
             * API Call Request URL
             */

             $url =  "https://api.flickr.com/services/rest/?";

             /*
              * Method We are using for this tutorial  flickr.tags.getHotList
              */

             $url.= "&method=flickr.tags.getHotList";

             /*
              * Put Your API Key HEre
              */

             $url.= "&api_key=9efc64af59f4d2c437ade6a2c95c5263";

             /*
              * Argument Period accepts two values [Day,Week] by default it is day
              */
             $url.= "&period=week";

             /*
              * Following two makes sure response is in JSON format
              */
             $url.= "&format=json";
             $url.= "&nojsoncallback=1";

$response = json_decode(file_get_contents($url));
$photo_array = $response->photos->photo;
//print_r($response);
echo "<ul>";

foreach ($response->hottags->tag as  $value) {
	
	echo "<li><a target='_blank' href='https://www.flickr.com/search/?q=$value->_content'>".$value->_content."</a></li>";	

}
echo "</ul>";



?>