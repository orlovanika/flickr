<?php

/*
* API Call Request URL
*/

$url = "https://api.flickr.com/services/rest/?";

/*
 * Method We are using for this tutorial  flickr.tags.getHotList
 */

$url .= "method=flickr.photos.search";

/*
 * Put Your API Key Here
 */

$url .= "&api_key=ebc8bbfa965360cc390bbd358f672b5f";

/*
 * Put name of the tag you want to search here, we use "cute" as an example here
 */

$url .= "&tags=cute";


/*
 * You can limit the number of search result with per_page
 */

$url .= "&per_page=5";


/*
 * Following two makes sure response is in JSON format
 */
$url .= "&format=json";
$url .= "&nojsoncallback=1";

/*
 * The returned result is an JSON object, which contains information to get the url of the images.
 */
$photos = json_decode(file_get_contents($url))->photos->photo;

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Flickr Photo Search - Tag: Cute</title>
</head>
<body>
<h1>Flickr Photo Search - Tag: Cute</h1>

<?php
/*
 * The format of an url: https://farm{farm-id}.staticflickr.com/{server-id}/{id}_{secret}.jpg
 * Substitute the argument in { } with the corresponding data from the search result, do not include { }
 */
?>

<?php foreach ($photos as $photo): ?>
    <h3><?php echo $photo->title ?></h3>
    <img
        src="https://farm<?php echo $photo->farm ?>.staticflickr.com/<?php echo $photo->server ?>/<?php echo $photo->id ?>_<?php echo $photo->secret ?>.jpg"
        alt="<?php echo $photo->title ?>"/>
    <br/>
    <hr/>
<?php endforeach ?>


</body>
</html>
